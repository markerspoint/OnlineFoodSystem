<?php include "nav/header.php"; ?>

<?php include "home.php"; ?>

<?php include "menuindex.php"; ?>

<?php include "nav/footer.php"; ?>